import 'package:flutter/material.dart';


//This extends stateless widget. Method below should create a scared state widget
class scared extends StatelessWidget {   
  scared createState() => scared();
  @override   
  Widget build(BuildContext context) {   
   
    return MaterialApp(   
        
      home: Scaffold(   
        appBar: AppBar(   
          title: Text('This is a scared face'),   
        ),   
           
        body: Center(   
          child: Column(               
            children: <Widget>[   
              Image.asset('assets/images/scared.jpg'),   
            ],   
          ),   
        ),   
      ),   
    );   
  }   
}   