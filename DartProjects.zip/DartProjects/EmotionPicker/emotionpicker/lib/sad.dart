import 'package:flutter/material.dart';


//This extends stateless widget

//This extends stateless widget. Method below should create a sad state widget
class sad extends StatelessWidget {   
 sad createState() => sad();
  @override   
  Widget build(BuildContext context) {   
   
    return MaterialApp(   
        
      home: Scaffold(   
        appBar: AppBar(   
          title: Text('This is a sad face'),   
        ),   
           
        body: Center(   
          child: Column(               
            children: <Widget>[   
              Image.asset('assets/images/sad.jpg'),   
            ],   
          ), 
          
        ), 
          
      ),   
    );   
  }   
}   