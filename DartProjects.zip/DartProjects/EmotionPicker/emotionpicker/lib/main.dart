import 'package:flutter/material.dart';

//imported classes
import 'sad.dart';
import 'happy.dart';
import 'angry.dart';
import 'scared.dart';

void main() => runApp(MyApp());

//Calls Stateless Widget
class MyApp extends StatelessWidget {
  final appTitle = 'Emotion Picker';

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: appTitle,
      home: MyHomePage(title: appTitle),
    );
  }
}
//This is the output for the stateless widget
class MyHomePage extends StatelessWidget {
  final String title;

  MyHomePage({Key key, this.title}) : super(key: key);
//This is where the Drawer is located
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: Center(child: Text('Pick and emotion')),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            
            //Drawer contains 4 listiles that have setState methods. Should change the state of the app upon tapping.
            DrawerHeader(
              child: Text('Drawer Header'),
              decoration: BoxDecoration(
                color: Colors.blue,
              ),
            ),

            ListTile(
              title: Text('angry'),
              onTap: () {
               angry();
                Navigator.pop(context);
              },
            ),
            ListTile(
              title: Text('happy'),
              onTap: () {
                happy();
                Navigator.pop(context);
              },
            ),
            ListTile(
              title: Text('sad'),
              onTap: () {
                sad();
                Navigator.pop(context);
              },
            ),
            ListTile(
              title: Text('scared'),
              onTap: () {
              scared();
                Navigator.pop(context);
              },
            ),

          ],
        ),
      ),
    );
  }
}