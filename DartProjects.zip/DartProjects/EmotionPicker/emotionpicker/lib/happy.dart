import 'package:flutter/material.dart';


//This extends stateless widget. Method below should create a happy state widget
class happy extends StatelessWidget {   
  happy createState() => happy();

  @override   
  Widget build(BuildContext context) {   
   
    return MaterialApp(   
        
      home: Scaffold(   
        appBar: AppBar(   
          title: Text('This is a Happy face'),   
        ),   
           
        body: Center(   
          child: Column(               
            children: <Widget>[   
              Image.asset('assets/images/happy.jpg'),   
            ],   
          ),   
        ),   
      ),   
    );   
  }   
}   