import 'package:flutter/material.dart';

class angry extends StatelessWidget {   


  //This extends stateless widget. Method below should create a scared angry widget
  angry createState() => angry();
  @override   
  Widget build(BuildContext context) {   
   
    return MaterialApp(   
        
      home: Scaffold(   
        appBar: AppBar(   
          title: Text('This is a Angry face'),   
        ),   
           
        body: Center(   
          child: Column(               
            children: <Widget>[   
              Image.asset('assets/images/angry.jpg'),   
            ],   
          ),   
        ),   
      ),   
    );   
  }   
}   