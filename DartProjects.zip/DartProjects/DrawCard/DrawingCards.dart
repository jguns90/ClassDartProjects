import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'deck.dart';



void main() {
  runApp(MyApp());
}



class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(title: Text("Draw Card")),
        body: ChangeNotifierProvider(
          create: (context)=> Cards(), 
          child: Cardpage()),
        )
        );
}
}

class Cardpage extends StatelessWidget{
  @override
  Widget build(BuildContext context){
    return Center(child: Consumer<Cards>(
      builder:(context, cards, child){
        return Column(
          children: [
            ListView(),
            RaisedButton(onPressed: cards.drawCard, child: Text("Draw Card")),
        ],
        );
      },
    ));
  
} 
}  
class Cards extends ChangeNotifier {
PlayingCard card = new PlayingCard();

  void drawCard(){
    card.createDeck();
      
      notifyListeners();
  }
 
  
}
 
 
