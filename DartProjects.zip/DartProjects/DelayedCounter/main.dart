import 'dart:async';

//Creating a Stream of Ints
Stream<int> MyIntStream(int num) async* {
  for (int i = 1; i <= num; i++) {
      yield i;
    }
  }
//IntOutPut controls the output of the Int stream
Future<int> IntOutPutStream(Stream<int> stream) async {
  var i = 1;
  await for (var myints in stream){
    //It took me hoooours to figure the ++ out but I got it :D
    Future.delayed(Duration(seconds: i++), () => print(myints));
  }
}
main() async {
  var intcap = 10;
  //Create variable Stream to hold my ints
  var stream = MyIntStream(intcap);
  //passes stream into my output Stream
  var Output = await IntOutPutStream(stream); 
}

