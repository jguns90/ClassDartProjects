
class Monster {
  int teeth;
  int claws;
  String scarephrase;



Monster.withTeeth(int numteeth, int numclaws, String scare){
  this.teeth = numteeth;
  this.claws = numclaws;
  this.scarephrase = scare;

}
Monster.withoutTeeth(int teeth, int numclaws, String scare){
this.teeth = 0;
this.claws = numclaws;
this.scarephrase = scare;

}
void sayScare(){
  print("With my $teeth teeth and $claws claws I shall scare you! $scarephrase");
}

}



main(){
Monster Mon1 = new Monster.withTeeth(52, 12, 'Ooga Booga Booga snarls');
Mon1.sayScare();

Monster Mon2 = new Monster.withoutTeeth(0, 16, 'Roaaaaarr.....wha wait!!! why are you laughing');
Mon2.sayScare();


}